package com.example.kindler.models;

public class Book {
    public String name;
    public String city;
    public String url;

    public Book(String name, String city, String url) {
        this.name = name;
        this.city = city;
        this.url = url;
    }
}

